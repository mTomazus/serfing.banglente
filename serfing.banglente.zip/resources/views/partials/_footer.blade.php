<div id="footer" class="footer mt-auto py-3">
    <div class="footer-box large container row">
        <div id="footer-nav" class="col-md">
            <ul class="nav flex-column">
                <li class="nav-item">
                    <a class="nav-link" href="/careers/">karjera</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/parama/">parama</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/ataskaitos/">ataskaitos</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/straipsniai/">straipsniai</a>
                </li>
            </ul>
        </div>

        <div class="footer-box">
            <object style="margin: auto;color:#30DE1B"><h2 class="hidden-xs-down">Susisiekite</h2>
                <div>
                    <p style="color:yellow">Mob: <i style="color:white">+370 686 02356</i><br>Email: <i style="color:white"> sales@banglente.com</i><br>Adresas:<br>Vėtros g. 8 Klaipėdoje</p></div>
            </object>
        </div>

        <div class="container row align-items-center justify-content-around" style="margin:auto">
            <div class="col col-sm-4" style="height:100%">
                <img src="/images/kms.png" style="z-index:0;max-height:100%;max-width:100%">
            </div>
            <div class="col col-sm-4" style="height:100%">
                <img src="/images/klaipeda.png" style="z-index:0;max-height:100%;max-width:100%">
            </div>
            <div class="col col-sm-4" style="height:100%">
                <img src="/images/kksd_logo.png" style="z-index:0;max-height:100%;max-width:100%">
            </div>
        </div>

    </div>
</div>