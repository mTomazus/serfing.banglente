<div>
    <h2 class="col-12">KONTAKTAI</h2>
    <div class="d-flex flex-wrap justify-content-between my-3">
        <?php $__currentLoopData = $lines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class='bg-white border d-flex col-4 p-1 m-1'>
                <div class="col-6">
                    <div><?php echo e($line->name); ?></div>
                    <div><?php echo e($line->email); ?></div>
                    <div class="small"><?php echo e($line->created_at); ?></div>
                </div>
                <div class="col-6 h5 p-1 m-1"><?php echo e($line->message); ?></div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>    
    <?php echo $lines->links(); ?>   
</div>
<?php /**PATH /home/tomas/Documents/Websites/Serfing/serfing.banglente/resources/views/livewire/contacts-table.blade.php ENDPATH**/ ?>