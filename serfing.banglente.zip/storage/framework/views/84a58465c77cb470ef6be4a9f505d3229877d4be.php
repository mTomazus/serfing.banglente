<div>
    <?php if($images): ?>
        Photo Preview:
        <div class="d-flex row">
        <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <img class="col-3" src="<?php echo e($image->temporaryUrl()); ?>">
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>    

    <?php $__errorArgs = ['images.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    
    <div class="bg-light p-3">
        <div class="mb-3">Gallery images</div>
        <form class="input-group" wire:submit.prevent="uploadImages">
            <input type="file" class="form-control" id="inputGroupFiles" aria-describedby="inputGroupFileAddon" aria-label="Upload" wire:model="images" multiple>
            <button type="submit" class="btn btn-outline-secondary"  id="inputGroupFileAddon">Upload</button>
        </form>
    </div>
</div>
<?php /**PATH /home/tomas/Documents/Websites/Serfing/serfing.banglente/resources/views/livewire/image-upload.blade.php ENDPATH**/ ?>