<?php $__env->startSection('content'); ?>

    <div class="content bg-grad section">
        <div class="vh-92 container">
            <div class="row col-sm-5 mx-auto justify-content-center">
                <div class="mt-5 col-12">
                    <div>
                        <div class="card-body">
                            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('login-register')->html();
} elseif ($_instance->childHasBeenRendered('hWynuQY')) {
    $componentId = $_instance->getRenderedChildComponentId('hWynuQY');
    $componentTag = $_instance->getRenderedChildComponentTagName('hWynuQY');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('hWynuQY');
} else {
    $response = \Livewire\Livewire::mount('login-register');
    $html = $response->html();
    $_instance->logRenderedChild('hWynuQY', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

    <script type="text/javascript" src="/js/topnav.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW" crossorigin="anonymous"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tomas/Documents/Websites/Serfing/serfing.banglente/resources/views/login.blade.php ENDPATH**/ ?>