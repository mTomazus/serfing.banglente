<?php $__env->startSection('content'); ?>

<div class="section bg-grad">
    <div class="content vh-92 d-block">
        <div class="container">
            <h1><?php echo e($post->title); ?></h1>
            <article class="bg-white">
                <h3>Kaina <?php echo e($post->price); ?> Eur</h3>
                <div>
                    <?php echo e($post->body); ?>

                </div>
                
                <div class="d-block btn-group m-2 p-2">
                    <a href="/posts/" class="btn btn-outline-secondary btn-sm">Back</a>
                    
                    <?php if(Auth::user() && Auth::user()->type == 'admin'): ?>
                        <a href="/posts/<?php echo e($post->id); ?>/edit" class="btn btn-outline-primary btn-sm">Edit</a>
                        
                        <?php echo Form::open(['action' => ['App\Http\Controllers\User\PostsController@destroy', $post->id], 'method' => 'POST', 'class' => 'd-inline']); ?>

                            <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                            <?php echo e(Form::submit('Delete', ['class' => 'btn btn-sm btn-outline-danger'])); ?>

                        <?php echo Form::close(); ?>

                    <?php endif; ?>

                </div>    
                <small class="m-2 d-block">Sukurta <?php echo e($post->created_at); ?></small>
                
            </article>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('meta'); ?>

    <title>Skelbimas - <?php echo e($post->title); ?></title>
    <meta name="description" content="Banglenčių ir kito surf equipmento turgelis.">
    <meta name="keywords" content="banglentes, SUP, bodyboardai, banglenčių nuoma, mokykla, nuoma, turgus, skelbimai, hidrokostiumai, riedlentės, melnrage, klaipeda, molas, surf, spotas">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

    <script type="text/javascript" src="js/topnav.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW" crossorigin="anonymous"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tomas/Documents/Websites/Serfing/serfing.banglente/resources/views/user/posts/show.blade.php ENDPATH**/ ?>