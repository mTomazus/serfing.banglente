<div class="mx-auto">    

    <div>
        <?php if(session()->has('message')): ?>
            <div class="alert h4 alert-success">
                <?php echo e(session('message')); ?>

            </div>
        <?php endif; ?>
    </div>
    
    <form wire:submit.prevent="submitForm" class="col-12 mx-auto p-3">

        <?php echo csrf_field(); ?>

        <div class="row">
            <div class="col form-group">
                <label class="text-white" for="exampleInputName">Vardas</label>
                <input type="text" class="form-control" id="exampleInputName" placeholder="Įveskite savo vardą" wire:model="name">
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col form-group">
                <label class="text-white" for="exampleInputEmail">El. paštas</label>
                <input type="text" class="form-control" id="exampleInputEmail" placeholder="Įveskite el. paštą" wire:model="email">
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <div class="form-group">
            <label class="text-white" for="exampleInputMessage">Žinutė</label>
            <textarea class="form-control" id="exampleInputbody" placeholder="Rašykite savo žinutę" wire:model="message"></textarea>
            <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <button type="submit" class="mt-3 btn btn-primary">Siųsti</button>

    </form>
    
</div><?php /**PATH /home/tomas/Documents/Websites/Serfing/serfing.banglente/resources/views/livewire/contact-form.blade.php ENDPATH**/ ?>