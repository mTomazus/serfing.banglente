<?php $__env->startSection('content'); ?>

    <div class="section content bg-grad">

        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('data-table', [])->html();
} elseif ($_instance->childHasBeenRendered('XI6bsGW')) {
    $componentId = $_instance->getRenderedChildComponentId('XI6bsGW');
    $componentTag = $_instance->getRenderedChildComponentTagName('XI6bsGW');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('XI6bsGW');
} else {
    $response = \Livewire\Livewire::mount('data-table', []);
    $html = $response->html();
    $_instance->logRenderedChild('XI6bsGW', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        
    </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tomas/Documents/Websites/Serfing/serfing.banglente/resources/views/data-table.blade.php ENDPATH**/ ?>