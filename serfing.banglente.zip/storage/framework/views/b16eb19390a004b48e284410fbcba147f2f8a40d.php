<div>
    <div class="mx-auto">
        <form wire:submit.prevent="submitChat" class="col-12 mx-auto p-3">
    
            <?php echo csrf_field(); ?>
            <?php if(auth()->guard()->check()): ?>
                <div class="input-group mb-2">
                    <input class="form-control" type="text" placeholder="Rašykite savo žinutę" wire:model="message">
                    <input type="hidden" wire:model="name">
                    <input type="hidden" wire:model="user_id">    
                    <button type="submit" class="btn btn-primary">Siųsti</button>
                </div>
                <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <?php endif; ?>
            <div class="chat-box" style="max-height: 550px; overflow-y: clip;">
                <?php $__currentLoopData = $lines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($loop->even): ?>
                        <div class='btn-group w-100 mb-1'>
                            <span class="fw-bold btn btn-info"><?php echo e($line->user_id); ?></span>
                            <span class="btn btn-light w-100" style='word-wrap:anywhere'><?php echo e($line->message); ?></span>
                        </div>
                    <?php elseif($loop->odd): ?>
                        <div class='btn-group w-100 mb-1'>
                            <span class="btn btn-light w-100" style='word-wrap:anywhere'><?php echo e($line->message); ?></span>
                            <span class="fw-bold btn btn-success"><?php echo e($line->user_id); ?></span>
                        </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </form>
        
    </div><?php /**PATH /home/tomas/Documents/Websites/Serfing/serfing.banglente/resources/views/livewire/chat-form.blade.php ENDPATH**/ ?>