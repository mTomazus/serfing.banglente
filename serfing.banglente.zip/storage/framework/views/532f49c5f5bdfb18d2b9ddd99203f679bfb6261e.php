<?php $__env->startSection('content'); ?>

<div class="section bg-grad">
    <div class="content vh-100 d-block">
        <div class="container mt-3">
            <div class="mt-lg-5 col-mg-8 mx-auto">
                <h1 class="h1 fw-bold">Naujas skelbimas</h1>
                <?php if($errors->any()): ?>
                    <ul class="col-lg-10 m-auto">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="alert alert-danger">
                                <li><strong>Danger!</strong><?php echo e($error); ?></li>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                <?php endif; ?>
                <?php echo Form::open(['action' => 'App\Http\Controllers\User\PostsController@store', 'method' => 'POST', 'enctype' => 'multipart/form-data', 'class' => 'row col-md-6']); ?>

                    <div class="px-3 p-1">
                        <?php echo e(Form::label('title', 'Antraštė', ['class' => 'form-label'])); ?>

                        <?php echo e(Form::text('title', '', ['class' => 'form-control', 'placeholder' => 'Pora žodžių...'])); ?>

                    </div>
                    <div class="px-3 p-1">
                        <?php echo e(Form::label('body', 'Trumpa info', ['class' => 'form-label'])); ?>

                        <?php echo e(Form::textarea('body', '', ['class' => 'form-control', 'placeholder' => 'Apie 20 žodžių...', 'rows' => "3"])); ?>

                    </div>
                    <div class="px-3 p-1 col-6 ">
                        <?php echo e(Form::label('price', 'Kaina Eur', ['class' => 'form-label'])); ?>

                        <?php echo e(Form::text('price', '', ['class' => 'form-control', 'placeholder' => '150...'])); ?>

                    </div>
                    <div class="px-3 p-1 col-6">
                        <?php echo e(Form::label('phone', 'Telefono numeris', ['class' => 'form-label'])); ?>

                        <?php echo e(Form::text('phone', '', ['class' => 'form-control', 'placeholder' => '+370 6xx xxxxx'])); ?>

                    </div>
                    <div class="px-3 mb-3 p-1">
                        <?php echo e(Form::label('category', 'Įrangos kategorija', ['class' => 'form-label'])); ?>

                        <?php echo e(Form::select('category', ['Surf' => 'Surfboards', 'Kite' => 'Kite', 'Wetsuit' => 'Wetsuits', 'Skate' => 'Skateboards', 'Wind' => 'Wind', 'Kita' => 'Kita'], 'Pasirenkam..', ['class' => 'form-select'])); ?>

                    </div>
                    <div class="col-10 mb-3 mx-auto">
                        <div class="input-group p-1">
                            <label class="input-group-text" for="image_1">Pic1</label>
                            <?php echo e(Form::file('image_1', ['class' => 'form-control'])); ?>

                        </div>
                        <div class="input-group p-1">
                            <label class="input-group-text" for="image_2">Pic2</label>
                            <input class="form-control" type="file" name="image_2[]" multiple>
                        </div>
                        <div class="input-group p-1">
                            <label class="input-group-text" for="image_3">Pic3</label>
                            <?php echo e(Form::file('image_3', ['class' => 'form-control'])); ?>

                        </div>
                    </div>
                    <div class="px-3 text-center mb-1 p-1">
                        <?php echo e(Form::submit('Submit', ['class' => 'mb-2 btn btn-primary'])); ?>

                    </div>
                <?php echo Form::close(); ?>

                </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('meta'); ?>

    <title>Skelbimai - kurti naują</title>
    <meta name="description" content="Banglenčių ir kito surf equipmento turgus.">
    <meta name="keywords" content="banglentes, SUP, bodyboardai, banglenčių nuoma, mokykla, nuoma, turgus, skelbimai, hidrokostiumai, riedlentės, melnrage, klaipeda, molas, surf, spotas">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

    <script type="text/javascript" src="/js/topnav.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW" crossorigin="anonymous"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tomas/Documents/Websites/Serfing/serfing.banglente/resources/views/user/posts/create.blade.php ENDPATH**/ ?>