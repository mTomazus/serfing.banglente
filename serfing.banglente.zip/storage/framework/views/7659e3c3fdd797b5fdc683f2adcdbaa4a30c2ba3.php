<?php $__env->startSection('content'); ?>

    <div class="section content bg-grad">

        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('pamokos-table', [])->html();
} elseif ($_instance->childHasBeenRendered('c1BzJ5P')) {
    $componentId = $_instance->getRenderedChildComponentId('c1BzJ5P');
    $componentTag = $_instance->getRenderedChildComponentTagName('c1BzJ5P');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('c1BzJ5P');
} else {
    $response = \Livewire\Livewire::mount('pamokos-table', []);
    $html = $response->html();
    $_instance->logRenderedChild('c1BzJ5P', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        
    </div>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('meta'); ?>

    <title>Banglentė - admin panel - pamokų forma</title>
    <meta name="description" content="Griebiam banglentes ir į bangas, išsinuomuok banglente , SUPą Klaipėdoje ir Melnragėje, banglenčių mokykla.">
    <meta name="keywords" content="banglentes, SUP, bodyboardai, banglenčių nuoma, mokykla, nuoma, varžybos, lietuva, hidrokostiumai, riedlentės, melnrage, klaipeda, molas, surf, spotas">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

    <script type="text/javascript" src="js/topnav.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW" crossorigin="anonymous"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tomas/Documents/Websites/Serfing/serfing.banglente/resources/views/admin/pamokos-table.blade.php ENDPATH**/ ?>