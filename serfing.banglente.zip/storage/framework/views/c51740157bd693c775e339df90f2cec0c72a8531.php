<?php $__env->startSection('content'); ?>

<div class="section bg-grad">
    <div class="content vh-92 d-block">
        <div class="container my-3">        
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('image-upload', [])->html();
} elseif ($_instance->childHasBeenRendered('H2Zz2xz')) {
    $componentId = $_instance->getRenderedChildComponentId('H2Zz2xz');
    $componentTag = $_instance->getRenderedChildComponentTagName('H2Zz2xz');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('H2Zz2xz');
} else {
    $response = \Livewire\Livewire::mount('image-upload', []);
    $html = $response->html();
    $_instance->logRenderedChild('H2Zz2xz', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('meta'); ?>

    <title>Surf galerija</title>
    <meta name="description" content="Banglenčių sporto galerija.">
    <meta name="keywords" content="banglentes, SUP, bodyboardai, banglenčių nuoma, mokykla, nuoma, turgus, skelbimai, hidrokostiumai, riedlentės, melnrage, klaipeda, molas, surf, spotas">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

    <script type="text/javascript" src="/js/topnav.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW" crossorigin="anonymous"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tomas/Documents/Websites/Serfing/serfing.banglente/resources/views/images.blade.php ENDPATH**/ ?>