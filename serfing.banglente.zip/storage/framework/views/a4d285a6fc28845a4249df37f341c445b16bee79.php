<?php $__env->startSection('content'); ?>

    <div class="section content bg-grad">

        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('data-table', [])->html();
} elseif ($_instance->childHasBeenRendered('vwabAda')) {
    $componentId = $_instance->getRenderedChildComponentId('vwabAda');
    $componentTag = $_instance->getRenderedChildComponentTagName('vwabAda');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('vwabAda');
} else {
    $response = \Livewire\Livewire::mount('data-table', []);
    $html = $response->html();
    $_instance->logRenderedChild('vwabAda', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        
    </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tomas/Documents/Websites/Serfing/serfing.banglente/resources/views/table.blade.php ENDPATH**/ ?>