<?php $__env->startSection('content'); ?>

    <div class="section content bg-grad">

        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('contacts-table', [])->html();
} elseif ($_instance->childHasBeenRendered('SmHIbog')) {
    $componentId = $_instance->getRenderedChildComponentId('SmHIbog');
    $componentTag = $_instance->getRenderedChildComponentTagName('SmHIbog');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('SmHIbog');
} else {
    $response = \Livewire\Livewire::mount('contacts-table', []);
    $html = $response->html();
    $_instance->logRenderedChild('SmHIbog', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        
    </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tomas/Documents/Websites/Serfing/serfing.banglente/resources/views/contacts-table.blade.php ENDPATH**/ ?>