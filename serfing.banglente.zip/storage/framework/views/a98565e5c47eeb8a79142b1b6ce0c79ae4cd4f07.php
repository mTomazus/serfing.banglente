<div class="bg-white f-small mb-4">
    <form wire:submit.prevent="submitStovyklaForm" class="p-3">

        <?php echo csrf_field(); ?>

        <div>
            <?php if(session()->has('message')): ?>
                <div class="alert h4 alert-success text-center">
                    <?php echo e(session('message')); ?>

                </div>
            <?php endif; ?>
        </div>

        <div class="input-group p-3">
            <div class="input-group-append">
                <label class="input-group-text" for="pamaina">Stovyklos pamaina</label>
            </div>
            <select class="custom-select" name="pamaina" id="pamaina" wire:model="pamaina">
                <option value="-1">Pasirinktite</option>
                <option value="1. Birželio 14d." disabled>1. Pretęsti mokslo metai</option>
                <option value="2. Birželio 21d." disabled>2. Pretęsti mokslo metai</option>
                <option value="3. Birželio 28d." disabled>3. Pamaina pilna</option>
                <option value="4. Liepos 5d." disabled>4. Pamaina pilna</option>
                <option value="5. Liepos 12d." disabled>5. Pamaina pilna</option>
                <option value="6. Liepos 19d." disabled>6. Pamaina pilna</option>
                <option value="7. Liepos 26d." disabled>7. Pamaina pilna.</option>
                <option value="8. Rugpjūčio 2d." disabled>8. Pamaina pilna</option>
                <option value="9. Rugpjūčio 9d." disabled>9. Pamaina pilna</option>
                <option value="10. Rugpjūčio 16d." disabled>10. Pamaina pilna</option>
                <option value="11.	Rugpjūčio 23d." disabled>11. Pamaina pilna</option>
            </select>
            <?php $__errorArgs = ['pamaina'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger small error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        
        <div class="col-11 mx-auto row mb-3">
            <div class="col">
                <input type="text" class="form-control" placeholder="Vardas" wire:model="name">
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger small error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col">
                <input type="text" class="form-control" placeholder="Pavardė" wire:model="surname">
                <?php $__errorArgs = ['surname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger small error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
        <div class="col-10 mx-auto mb-3">
            <input class="form-control" type="text" placeholder="Gyvenamoji vieta" aria-label="default input example" wire:model="address">
            <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger small error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="row mb-3 justify-content-around">
            <div class="input-group w-auto">
                <div class="input-group-append">
                    <label class="input-group-text" for="metai" aria-describedby="metai">Metai</label>
                </div>
                <select class="custom-select" name="metai" id="metai" wire:model="age">
                    <option value="10">10</option>
                    <option value="11">11</option>
                    <option value="12">12</option>
                    <option value="13" selected>13</option>
                    <option value="14">14</option>
                    <option value="15">15</option>
                    <option value="16">16</option>
                    <option value="17">17</option>
                    <option value="18">18</option>
                    <option value="9">9</option>
                </select>
            </div>
            <div class="input-group w-auto">
                <div class="input-group-append">
                    <label class="input-group-text" for="plaukti" aria-describedby="plaukti">Plaukia:</label>
                </div>
                <select class="custom-select" name="plaukti" id="plaukti" wire:model="swim">
                    <option value="gerai" selected>Gerai</option>
                    <option value="silpnai">Silpnai</option>
                </select>
            </div>
        </div>
        <div class="col-9 mx-auto form-group mb-3">
            <input class="form-control" type="text" name="alergija" aria-describedby="alergija" placeholder="Ar alergiškas ir kam ?" wire:model="alergy">
        </div>
        <div class="form-group col-7 mb-3 mx-auto">                    
            <input class="form-control" type="email" name="email" aria-describedby="emailHelp" placeholder="Elektroninis paštas" wire:model="email">
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger small error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group col-5 mb-3 mx-auto">
            <input type="tel" class="form-control" name="phone" aria-describedby="phoneHelp" placeholder="Telefono numeris" maxlength="14" wire:model="phone">
            <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger small error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="text-center pb-3">
            <button  type="submit" name="submit" class="btn btn-primary ml-2 col-5" >Registruoti</button>
        </div>
    </form>
</div><?php /**PATH /home/tomas/Documents/Websites/Serfing/serfing.banglente/resources/views/livewire/stovykla-form.blade.php ENDPATH**/ ?>