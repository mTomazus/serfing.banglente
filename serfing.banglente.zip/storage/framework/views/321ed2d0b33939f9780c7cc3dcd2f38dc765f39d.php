<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Stovyklos Registracija</title>
</head>
<body>
    
    <div style="background: #4ac4e2;text-align: center;width: 320px;margin:auto;padding:.5rem;">
        <h1>Stovyklos Registracija</h1>
        <h2>from <?php echo e($sendername); ?> <?php echo e($sendersurname); ?></h2>
    </div> 
    <br>
    <div>
        <pre>
            <table style="margin:auto;width:100%;text-align:left;border: 2px solid grey;padding: 0.5rem;">
                <tr style="background: khaki;">
                    <th>Pamaina</th>
                    <th>Vardas Pavardė</th>
                    <th>Metai</th>
                    <th>Adresas</th>
                    <th>Telefonas</th>
                    <th>El.Paštas</th>
                </tr>
                <tr>
                    <td><?php echo e($senderpamaina); ?></td>
                    <td><?php echo e($sendername); ?> <?php echo e($sendersurname); ?></td>
                    <td><?php echo e($senderage); ?></td>
                    <td><?php echo e($senderaddress); ?></td>
                    <td><?php echo e($senderphone); ?></td>
                    <td><?php echo e($senderemail); ?></td>
                </tr>
            </table>
        </pre>
    </div>
</body>
</html><?php /**PATH /home/tomas/Documents/Websites/Serfing/serfing.banglente/resources/views/emails/fromStovykla.blade.php ENDPATH**/ ?>