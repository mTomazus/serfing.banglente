<?php $__env->startSection('content'); ?>

    <div class="section content bg-grad">

        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('pamokos-table', [])->html();
} elseif ($_instance->childHasBeenRendered('f4ztidR')) {
    $componentId = $_instance->getRenderedChildComponentId('f4ztidR');
    $componentTag = $_instance->getRenderedChildComponentTagName('f4ztidR');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('f4ztidR');
} else {
    $response = \Livewire\Livewire::mount('pamokos-table', []);
    $html = $response->html();
    $_instance->logRenderedChild('f4ztidR', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        
    </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tomas/Documents/Websites/Serfing/serfing.banglente/resources/views/pamokos-table.blade.php ENDPATH**/ ?>