<?php $__env->startSection('content'); ?>

<div class="section bg-grad">
    <div class="content vh-92 d-block">
        <div class="container">
            <h1 class="h1 fw-bold my-2"><?php echo e($post->title); ?></h1>
            <small class="m-2 text-center d-block">Sukurta <?php echo e($post->created_at); ?></small>
            <figure>
                <img class="w-100" src="<?php echo e(asset('user_images/' . $post->image_1)); ?>" alt="<?php echo e($post->title); ?> pirmas">
                <img class="w-100" src="<?php echo e(asset('user_images/' . $post->image_2)); ?>" alt="<?php echo e($post->title); ?> antras">
                <img class="w-100" src="<?php echo e(asset('user_images/' . $post->image_3)); ?>" alt="<?php echo e($post->title); ?> trecias">
            </figure>
            <h3 class="text-white fw-bold">Kaina <?php echo e($post->price); ?> Eur</h3>
            
            <article class="p-2 mb-2 bg-white">
                <div>
                    <?php echo e($post->body); ?>

                </div>
            </article>

            <h3 class="text-white fw-bold">Ph.: <?php echo e($post->phone); ?></h3>
            
            <div class="d-block text-center btn-group m-2 p-2">
                <a href="/skelbimai/" class="btn btn-secondary btn-sm">Back</a>
                <?php if(Auth::user() && Auth::user()->id == $post->user_id): ?>
                        <a href="/posts/<?php echo e($post->id); ?>/edit" class="btn btn-primary btn-sm">Edit</a>
                        
                        <?php echo Form::open(['action' => ['App\Http\Controllers\User\PostsController@destroy', $post->id], 'method' => 'POST', 'class' => 'd-inline']); ?>

                            <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                            <?php echo e(Form::submit('Delete', ['class' => 'btn btn-sm btn-danger'])); ?>

                        <?php echo Form::close(); ?>

                <?php endif; ?>
            </div>  
            
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('meta'); ?>

    <title>Skelbimas - <?php echo e($post->title); ?></title>
    <meta name="description" content="Banglenčių ir kito surf equipmento turgelis.">
    <meta name="keywords" content="banglentes, SUP, bodyboardai, banglenčių nuoma, mokykla, nuoma, turgus, skelbimai, hidrokostiumai, riedlentės, melnrage, klaipeda, molas, surf, spotas">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

    <script type="text/javascript" src="/js/topnav.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW" crossorigin="anonymous"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tomas/Documents/Websites/Serfing/serfing.banglente/resources/views/show.blade.php ENDPATH**/ ?>