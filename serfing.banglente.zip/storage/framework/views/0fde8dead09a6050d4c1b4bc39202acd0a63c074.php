<?php $__env->startSection('content'); ?>

    <div class="section content bg-grad">

        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('pamokos-table', [])->html();
} elseif ($_instance->childHasBeenRendered('qU4f10m')) {
    $componentId = $_instance->getRenderedChildComponentId('qU4f10m');
    $componentTag = $_instance->getRenderedChildComponentTagName('qU4f10m');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('qU4f10m');
} else {
    $response = \Livewire\Livewire::mount('pamokos-table', []);
    $html = $response->html();
    $_instance->logRenderedChild('qU4f10m', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        
    </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tomas/Documents/Websites/Serfing/serfing.banglente/resources/views//admin/pamokos-table.blade.php ENDPATH**/ ?>