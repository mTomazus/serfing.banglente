<div class="data-table vh-92">

    <div class="col-11 mx-auto mt-4">

        <h2 class="mb-4">STOVYKLOS FORMA</h2>
        
        <table>
        
            <tr>
                <th class="px-4 py-2">Pamaina</th>
                <th class="px-4 py-2">Vardas</th>
                <th class="px-4 py-2">Pavardė</th>
                <th class="px-4 py-2">Amžius</th>
                <th class="px-4 py-2">Adresas</th>
                <th class="px-4 py-2">Telefonas</th>
                <th class="px-4 py-2">El.paštas</th>
                <th class="px-4 py-2">Sukurta</th>
            </tr>
    
            <?php $__currentLoopData = $lines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="border px-4 py-2"><?php echo e($line->pamaina); ?></td>
                    <td class="border px-4 py-2"><?php echo e($line->name); ?></td>
                    <td class="border px-4 py-2"><?php echo e($line->surname); ?></td>
                    <td class="border px-4 py-2"><?php echo e($line->age); ?></td>
                    <td class="border px-4 py-2"><?php echo e($line->address); ?></td>
                    <td class="border px-4 py-2"><?php echo e($line->phone); ?></td>
                    <td class="border px-4 py-2"><?php echo e($line->email); ?></td>
                    <td class="border px-4 py-2"><?php echo e($line->created_at); ?></td>
                    
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
        </table>

        <?php echo $lines->links(); ?>


    </div>
    
</div>
<?php /**PATH /home/tomas/Documents/Websites/Serfing/serfing.banglente/resources/views/livewire/stovykla-table.blade.php ENDPATH**/ ?>