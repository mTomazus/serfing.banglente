<?php $__env->startSection('content'); ?>

<div class="content section vh-92 bg-grad"">
    <div class="mt-0">
        <?php if(session()->has('message')): ?>
            <div class="alert h4 alert-success">
                <?php echo e(session('message')); ?>

            </div>
        <?php endif; ?>
    </div>

    <div class="w-100">
        <div class="content-side w-90 flex-column d-flex mx-auto">
            <div class="row">
                <div class="col my-5">
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('reserv-form', [])->html();
} elseif ($_instance->childHasBeenRendered('VtCRH9j')) {
    $componentId = $_instance->getRenderedChildComponentId('VtCRH9j');
    $componentTag = $_instance->getRenderedChildComponentTagName('VtCRH9j');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('VtCRH9j');
} else {
    $response = \Livewire\Livewire::mount('reserv-form', []);
    $html = $response->html();
    $_instance->logRenderedChild('VtCRH9j', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                </div>
            </div>
            <div class="row">
                <div class="col">
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('coupon-form', [])->html();
} elseif ($_instance->childHasBeenRendered('fsXtopT')) {
    $componentId = $_instance->getRenderedChildComponentId('fsXtopT');
    $componentTag = $_instance->getRenderedChildComponentTagName('fsXtopT');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('fsXtopT');
} else {
    $response = \Livewire\Livewire::mount('coupon-form', []);
    $html = $response->html();
    $_instance->logRenderedChild('fsXtopT', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('meta'); ?>

    <title>Banglentė - admin panel - home</title>
    <meta name="description" content="Griebiam banglentes ir į bangas, išsinuomuok banglente , SUPą Klaipėdoje ir Melnragėje, banglenčių mokykla.">
    <meta name="keywords" content="banglentes, SUP, bodyboardai, banglenčių nuoma, mokykla, nuoma, varžybos, lietuva, hidrokostiumai, riedlentės, melnrage, klaipeda, molas, surf, spotas">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

    <script type="text/javascript" src="js/topnav.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW" crossorigin="anonymous"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tomas/Documents/Websites/Serfing/serfing.banglente/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>