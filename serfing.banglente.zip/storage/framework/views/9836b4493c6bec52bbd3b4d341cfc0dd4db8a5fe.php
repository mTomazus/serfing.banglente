<?php $__env->startSection('content'); ?>

    <div class="section content bg-grad">

        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('camp-table', [])->html();
} elseif ($_instance->childHasBeenRendered('l75AxGX')) {
    $componentId = $_instance->getRenderedChildComponentId('l75AxGX');
    $componentTag = $_instance->getRenderedChildComponentTagName('l75AxGX');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l75AxGX');
} else {
    $response = \Livewire\Livewire::mount('camp-table', []);
    $html = $response->html();
    $_instance->logRenderedChild('l75AxGX', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        
    </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tomas/Documents/Websites/Serfing/serfing.banglente/resources/views/stovykla-table.blade.php ENDPATH**/ ?>