<div>

    <div class="container bg-def shadow py-2">

        <h2 class="">KUPONAI</h2>

        <div class="mb-4">
            <?php $__currentLoopData = $coups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="btn-group w-100 flex-column mb-1 flex-sm-row">
                    <span class="fw-bold btn btn-info"><?php echo e($coup->number); ?></span>
                    <span class="btn btn-light" style='word-wrap:anywhere'><?php echo e($coup->name); ?></span>
                    <span class="fw-bold btn btn-success"><?php echo e($coup->price); ?>€</span>
                    <div class="input-group-text">
                        <input class="form-check-input mt-0" type="checkbox" value="" aria-label="Checkbox for following text input">
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div> 

        <form wire:submit.prevent="submitCoupon" class="coupon-form"> 

            <?php echo csrf_field(); ?>

            <div class="col-10 mx-auto">
                
                <select class="form-select" name="pamoka" wire:model="service">
                    <option value="-1">pasirinkite kuponą...</option>
                    <option value="pamokų paketas">Pamokų paketas</option>
                    <option value="privati pamoka">Privati pamoka</option>
                    <option value="grupinė pamoka">Grupinė pamoka</option>
                    <option value="pamoka dviem">Pamoka dviem</option>
                    <option value="individuali plius">Individuali +</option>
                </select>                          
                
            </div>

            <div class="row my-3 mx-auto col-9">
                <input type="text" name="name" class="form-control" placeholder="Vardas Pavardė" aria-label="Full Name" wire:model="name">
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger small"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="row my-3 mx-auto col-8">
                <input type="email" name="email" class="form-control" placeholder="Elektroninis paštas" wire:model="email">
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger small"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>   

            <div class="row col-10 mx-auto my-3">
                <div class="col-5">
                    <input type="text" name="price" class="form-control" id="floatingInput" placeholder="Kaina" wire:model="price">
                    <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger small"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-7">
                    <input type="text" name="number" id="floatingInput2" class="form-control" placeholder="Kupono nr." wire:model="number">
                    <?php $__errorArgs = ['number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger small"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <div class="my-3 col-auto text-center mb-3">
                <button type="submit" class="btn btn-primary ">SUBMIT</button>
            </div>

        </form>

    </div>

</div><?php /**PATH /home/tomas/Documents/Websites/Serfing/serfing.banglente/resources/views/livewire/coupon-form.blade.php ENDPATH**/ ?>