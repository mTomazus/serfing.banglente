<?php $__env->startSection('content'); ?>

<div class="section bg-grad">
    <div class="content vh-92 d-block">
        <h1>KUPONAI</h1>
        <div class="d-flex lg my-4">
            <div class="content-box">
                <h2 class="shadow">KUPONAI</h2>
            </div>
            
            <div class="content-side">
                    
                <h2 class="shadow">NAUJAS KUPONAS</h2>
                <div class="container my-3">        
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('coupon-form', [])->html();
} elseif ($_instance->childHasBeenRendered('eGX4tMh')) {
    $componentId = $_instance->getRenderedChildComponentId('eGX4tMh');
    $componentTag = $_instance->getRenderedChildComponentTagName('eGX4tMh');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('eGX4tMh');
} else {
    $response = \Livewire\Livewire::mount('coupon-form', []);
    $html = $response->html();
    $_instance->logRenderedChild('eGX4tMh', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('meta'); ?>

    <title>Kuponai</title>
    <meta name="description" content="Banglenčių sporto dovanų kuponai.">
    <meta name="keywords" content="banglentes, SUP, bodyboardai, banglenčių nuoma, mokykla, nuoma, turgus, skelbimai, hidrokostiumai, riedlentės, melnrage, klaipeda, molas, surf, spotas">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

    <script type="text/javascript" src="/js/topnav.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW" crossorigin="anonymous"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tomas/Documents/Websites/Serfing/serfing.banglente/resources/views/coupons.blade.php ENDPATH**/ ?>