<?php return array (
  'chat-form' => 'App\\Http\\Livewire\\ChatForm',
  'contact-form' => 'App\\Http\\Livewire\\ContactForm',
  'contacts-table' => 'App\\Http\\Livewire\\ContactsTable',
  'coupon-form' => 'App\\Http\\Livewire\\CouponForm',
  'image-upload' => 'App\\Http\\Livewire\\ImageUpload',
  'login-register' => 'App\\Http\\Livewire\\LoginRegister',
  'pamokos-form' => 'App\\Http\\Livewire\\PamokosForm',
  'pamokos-table' => 'App\\Http\\Livewire\\PamokosTable',
  'reserv-form' => 'App\\Http\\Livewire\\ReservForm',
  'stovykla-form' => 'App\\Http\\Livewire\\StovyklaForm',
  'stovykla-table' => 'App\\Http\\Livewire\\StovyklaTable',
);